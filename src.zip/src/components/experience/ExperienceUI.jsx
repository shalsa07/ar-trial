'use client'
import { useExperienceContext } from '@/libs/contextProviders/experienceContext'
import { ACTIONS_EXPERIENCE } from '@/libs/contextProviders/reducerExperience'
import React, { useState } from 'react'
import { FaAngleRight } from "react-icons/fa6";
import { FaAngleLeft } from "react-icons/fa6";

export default function ExperienceUI({data}) {
    const {experienceState,experienceDispatch}=useExperienceContext()
    const [expandContainer,setExpandContainer]=useState(false)
    const [objectHiddenState,setObjectHiddenState]=useState(false)
    const [levelList,setLevelList]=useState(data?.hideLevel || [])
    const [levelListUpdate,setLevelListUpdate]=useState([])

    const options=['360s','model',' AR']
    const styleTopCss='btn-wrapper flex h-fit rounded-xl w-full bg-slate-500/50 items-center justify-center p-1 text-white gap-2 shadow'
    const styleCss='btn-wrapper flex flex-col h-fit rounded-2xl w-full bg-slate-400/35 items-center justify-center p-1 text-white gap-1 select-none'
    const styleBtnCss=`flex cursor-pointer items-center justify-center border-2 border-gray-400 p-1 bg-slate-600/75 shadow text-sm capitalize rounded-full cursor-pointer w-full min-h-10`

    const handleModeClick=(index)=>{
        // console.log('handleModeClick',index)
        index==0 && experienceDispatch({type:ACTIONS_EXPERIENCE._360_VIEW})
        index==1 && experienceDispatch({type:ACTIONS_EXPERIENCE.MODEL_VIEW})
        index==2 && experienceDispatch({type:ACTIONS_EXPERIENCE.AR_VIEW})
    }

    const handleHideLevelClick=(name)=>{
        // console.log('handleModeClick',name)
        const priorityList=[]
        levelList?.map(i=>priorityList?.push(i?.priority))
        if(!Array.isArray(priorityList)) {
            new Error("Input must be an array");
        }
        const lowestPriorityValue=Math.min(...priorityList)
        const matchIngObejct=levelList?.find(i=>i?.name===name)
        if(matchIngObejct?.priority==lowestPriorityValue){
            setObjectHiddenState(!objectHiddenState)
            setLevelList(!objectHiddenState ? [...levelList,matchIngObejct] : levelList?.filter(i=>i?.name!==matchIngObejct?.name))
            experienceDispatch({type:ACTIONS_EXPERIENCE.HIDE_LEVEL,payload:{nameOfObject:matchIngObejct?.name,visible:objectHiddenState}})
        }else{
            console.log('lowestPriorityValue doesnt macthes object')
        }
        console.log('show object', levelList)
    }

    // const handleHideLevelClick=(name)=>{
    //     // console.log('handleModeClick',name)
    //     const priorityList=[]
    //     levelList?.map(i=>priorityList?.push(i?.priority))
    //     if(!Array.isArray(priorityList)) {
    //         new Error("Input must be an array");
    //     }
    //     const lowestPriorityValue=Math.min(...priorityList)
    //     const heigestPriorityValue=Math.max(...priorityList)
    //     const matchIngObejct=levelList?.find(i=>i?.name===name)
    //     if(matchIngObejct?.priority==lowestPriorityValue){
    //         setObjectHiddenState(!objectHiddenState)
    //         experienceDispatch({type:ACTIONS_EXPERIENCE.HIDE_LEVEL,payload:{nameOfObject:matchIngObejct?.name,visible:objectHiddenState}})
    //         setLevelListUpdate(objectHiddenState ? levelList?.filter(i=>i?.name!==matchIngObejct?.name) : [...levelList])
    //     }else{
    //         console.log('lowestPriorityValue doesnt macthes object')
    //     }
    //     console.log('show object', levelListUpdate)
    // }

    // console.log('ExperienceUI:',experienceState)
  return (
    <>
        {/* 3D OPTIONS BUTTONS */}
        <div className='btn-options flex absolute gap-1 z-20 mX-auto top-20 w-fit rounded-2xl h-fit bg-black/75 items-center justify-center p-1 text-white'>
            {options?.map((i,index)=>
                <div onClick={()=>handleModeClick(index)} className={styleBtnCss} key={index}>
                    <span className='text-nowrap'>{i}</span>
                </div>
            )}
        </div>

        {/* VIEWS BUTTONS */}
        {(experienceState?.modelMode || experienceState?.ARMode) && <div className={`btns-left-container flex flex-col gap-2 absolute z-20 my-auto left-2 md:left-2 h-fit ${expandContainer ? 'w-44' : 'w-16'} bg-black/75 rounded-2xl p-1 duration-300 ease-linear`}>
            <div className='flex flex-col gap-2 w-full h-full relative'>
                {/* EXPAND TOGGLE BUTTON */}
                <div onClick={()=>setExpandContainer(!expandContainer)} className='flex absolute bg-gray-300 rounded-full items-center justify-center my-auto top-0 bottom-0 -right-5 w-8 h-8 text-gray-500/75'>
                    {expandContainer ? <FaAngleLeft/> : <FaAngleRight/>}
                </div>

                {/* LEVEL HIDE BUTTONS */}
                {data?.hideLevel?.length>0 && <div className={styleCss}>
                    {data?.hideLevel?.map((i,index)=>
                        <div onClick={()=>handleHideLevelClick(i?.name)} className={styleBtnCss} key={index}>
                            {!expandContainer ? <span className='truncate text-nowrap overflow-hidden'>{i?.name}</span> : <span className='text-center'>{i?.name}</span>}
                        </div>
                    )}
                </div>}

                {/* VIEWS BUTTONS */}
                {data?.roomSnaps?.length>0 && <div className={styleCss}>
                    {data?.roomSnaps?.map((i,index)=>
                        <div className={styleBtnCss} key={index}>
                            {!expandContainer ? <span className='truncate text-nowrap overflow-hidden'>{i?.name}</span> : <span className='text-center'>{i?.name}</span>}
                        </div>
                    )}
                </div>}

                {/* COLOR BUTTONS */}
                {data?.color?.length>0 && <div className={styleCss}>
                    {data?.color?.map((i,index)=>
                        <div className={styleBtnCss} key={index}>
                            {!expandContainer ? <span className='truncate text-nowrap overflow-hidden'>{i?.name}</span> : <span className='text-center'>{i?.name}</span>}
                        </div>
                    )}
                </div>}
            </div>
        </div>}
    </>
  )
}
