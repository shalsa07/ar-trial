'use client'
import React, { useEffect, useRef, useState } from 'react'
import ExperienceGLTFLoader from './ExperienceGLTFLoader'
import { useThree } from '@react-three/fiber'
import GUI from 'lil-gui'
import { useExperienceContext } from '@/libs/contextProviders/experienceContext'

export default function ExperienceModel({data}) {
    const {experienceState}=useExperienceContext()
    const {scene}=useThree()
    const [updateHideLevelState, setUpdateHideLevelState]=useState(false)
    const [updatedObjectsList, setUpdateObjectList]=useState(data?.hideLevel || [])
    const ref = useRef()

    useEffect(() => {
        const gui = new GUI()
        gui.add(ref.current.position, 'x', -100,100)
        gui.add(ref.current.position, 'y', -100,100)
        gui.add(ref.current.position, 'z', -100,100)
        
        return () => {
            gui.destroy()
        }
    }, [])

    useEffect(() => {
        if (data?.position) {
            const [x, y, z] = data.position.split(',').map(Number)
            ref.current.position.set(x, y, z)
        }
    }, [data?.position])

    useEffect(() => {
        handleHideLevel()
    }, [experienceState?.hidelevel])

    const handleHideLevel = () => {
        if(!experienceState?.hidelevel?.nameOfObject) return
        const objectMatch=scene?.getObjectByName(experienceState?.hidelevel?.nameOfObject)
        if(objectMatch && objectMatch?.visible){
            setUpdateHideLevelState(true)
            objectMatch.visible=experienceState?.hidelevel?.visible
        }
        else if(objectMatch && !objectMatch?.visible){
            setUpdateHideLevelState(false)
            objectMatch.visible=true
        }
        else{
            console.log('object not found')
        }
        // console.log('ExperienceModel:',updatedObjectsList)
    }
    
    // console.log('ExperienceModel:',updatedObjectsList)
  return (
    <group 
        ref={ref}
    >
        {data?.supportFiles?.map((i,index)=>
            <group key={index} name={i?.name}>
                <ExperienceGLTFLoader path={i}/>
            </group>
        )}
        {data?.hideLevel?.map((i,index)=>
            <group key={index} name={i?.name}>
                <ExperienceGLTFLoader path={i}/>
            </group>
        )}
        {data?.modelsFiles?.map((i,index)=>
            <group key={index}  name={i?.name}>
                <ExperienceGLTFLoader path={i}/>
            </group>
        )}
    </group>
  )
}
