import { useExperienceContext } from '@/libs/contextProviders/experienceContext'
import { OrbitControls } from '@react-three/drei'
import React from 'react'
import { degToRad } from 'three/src/math/MathUtils'

export default function ExpereinceControls({data}) {
  const {experienceState}=useExperienceContext()
    // console.log('ExpereinceControls:',experienceState?.firstPersonView?0.5 : data?.maxDistance)
  return (
    <OrbitControls
      enablePan={false}
      minDistance={experienceState?.firstPersonView ? 0 : data?.minDistance}
      maxDistance={experienceState?.firstPersonView ? 0.5 : data?.maxDistance}
      maxPolarAngle={degToRad(90)}
      minPolarAngle={degToRad(0)}
    />
  )
}
