import Link from 'next/link'
import React from 'react'

export default function page() {
  return (
    <div className='flex w-full h-svh items-center justify-center'>
      page
    </div>
  )
}
